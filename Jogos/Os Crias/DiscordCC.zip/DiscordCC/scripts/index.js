import "./events/handler.js"

console.info("DiscordCC has started.")