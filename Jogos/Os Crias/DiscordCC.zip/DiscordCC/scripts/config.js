// Make sure you read the official installation.
// This doesn't suppot client-side or realms.

export const config = {
  token: "MTQwNjE3MDk0MjQ3MTgwMjg4MQ.GKRs3z.pPm2CXNzYYHfmnFqGu_K3KnHXR7Mp0FicoONpk", // The discord bot token.
  channel: "1402110246335283311", // Channel ID for players from the server and people in discord server to chat on.
  webhook: "https://discord.com/api/webhooks/1406175762767282257/V3Btp8T1GxVaXS0ZRA9dYXE7XGkxbbe24jXmxQo8yu0_rt9of6SveW7fL0QP3ejJZs2U" // The webhook url of the same channel for the script to send a message from server to discord. 
}